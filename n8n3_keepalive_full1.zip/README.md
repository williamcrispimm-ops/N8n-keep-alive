# n8n KeepAlive + Alertas

Este projeto mantém todos os serviços ativos enviando pings automáticos e enviando alertas via Telegram.

## Deploy via Git no Render
1. Clone este repositório e configure seu GitHub.
2. Ajuste as variáveis no `render.yaml`.
3. Conecte no Render e selecione "Deploy from Git".
4. Disco persistente configurado em `/home/node/.n8n`.
