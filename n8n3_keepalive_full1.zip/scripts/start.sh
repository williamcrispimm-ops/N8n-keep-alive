#!/bin/bash
echo "Iniciando n8n KeepAlive com disco persistente..."
n8n start &
while true; do
  curl -s https://n8n-keepalive-alerts.onrender.com > /dev/null
  sleep 300
done
