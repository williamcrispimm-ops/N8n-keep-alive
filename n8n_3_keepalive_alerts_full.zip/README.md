# n8n 3 — Keep-Alive + Alertas (COMPLETO)

## O que faz
- A cada 5 min: pinga Render1, Render2, n8n1, n8n2 e ele mesmo (n8n3)
- Mantém contadores de falha (workflow static data, persistem entre execuções)
- Alerta no Telegram após 2 falhas seguidas
- Informa quando o serviço voltar

## Antes de importar
1) Defina no serviço do n8n (Render) as ENVs (ajuste URLs reais):
   - PING_RENDER1
   - PING_RENDER2
   - PING_N8N1
   - PING_N8N2
   - PING_SELF
   - TELEGRAM_ALERT_CHAT_ID
2) Crie a credencial **Telegram API** no n8n (Settings → Credentials).

## Importar
- n8n → Import → selecione `workflows/keepalive_alerts.json`
- Abra o workflow e, nos nós Telegram, selecione sua credencial.
- Ative o workflow.
